import SwiftUI
import MapKit
import CoreLocation
import Combine

struct FashionStoresView: View {
    @Environment(\.colorScheme) private var colorScheme
    @StateObject private var locationManager = LocationManager()
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 6.9271, longitude: 79.8612),
        span: MKCoordinateSpan(latitudeDelta: 0.08, longitudeDelta: 0.08)
    )
    @State private var selectedStore: FashionStore? = nil

    private let stores: [FashionStore] = [
        FashionStore(name: "Zara", coordinate: CLLocationCoordinate2D(latitude: 6.9184, longitude: 79.8540)),
        FashionStore(name: "H&M", coordinate: CLLocationCoordinate2D(latitude: 6.9279, longitude: 79.8487)),
        FashionStore(name: "ODEL", coordinate: CLLocationCoordinate2D(latitude: 6.9104, longitude: 79.8772)),
        FashionStore(name: "Cotton On", coordinate: CLLocationCoordinate2D(latitude: 6.9228, longitude: 79.8575)),
        FashionStore(name: "Fashion Bug", coordinate: CLLocationCoordinate2D(latitude: 6.8693, longitude: 79.8876))
    ]

    var body: some View {
        ZStack(alignment: .bottom) {
            Map(coordinateRegion: $region, showsUserLocation: true, annotationItems: stores) { store in
                MapAnnotation(coordinate: store.coordinate) {
                    Button {
                        selectedStore = store
                    } label: {
                        VStack(spacing: 2) {
                            Image(systemName: "tshirt")
                                .font(.system(size: 18, weight: .semibold))
                                .foregroundStyle(Color(hex: "F2A6B3"))
                                .padding(6)
                                .background(Circle().fill(.ultraThinMaterial))
                            Text(store.name)
                                .font(.caption2)
                                .foregroundStyle(.primary)
                                .padding(.horizontal, 4)
                                .padding(.vertical, 2)
                                .background(
                                    RoundedRectangle(cornerRadius: 6)
                                        .fill(Color(.systemBackground).opacity(0.9))
                                )
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
            .ignoresSafeArea()
            .onReceive(locationManager.$userLocation) { coordinate in
                guard let coordinate else { return }
                withAnimation(.easeInOut(duration: 0.35)) {
                    region.center = coordinate
                }
            }

            if let store = selectedStore {
                storeSheet(store: store)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .animation(.easeInOut(duration: 0.25), value: selectedStore != nil)
            }
        }
        .background(colorScheme == .dark ? Color(.systemGray6) : Color(.systemBackground))
        .onAppear {
            locationManager.requestLocation()
        }
        .navigationTitle("Nearby Stores")
    }

    private func storeSheet(store: FashionStore) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 6) {
                    Text(store.name)
                        .font(.headline)
                    if let distanceText = distanceText(for: store) {
                        Text(distanceText)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                }
                Spacer()
                Button(action: { selectedStore = nil }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 20))
                        .foregroundStyle(.secondary)
                }
                .buttonStyle(.plain)
            }

            Button {
                openInMaps(store: store)
            } label: {
                HStack {
                    Image(systemName: "map")
                    Text("Open in Maps")
                }
                .frame(maxWidth: .infinity)
            }
            .buttonStyle(AccentButtonStyle())
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 22)
                .fill(Color(.systemBackground).opacity(colorScheme == .dark ? 0.4 : 0.9))
                .shadow(color: Color.black.opacity(0.18), radius: 20, x: 0, y: 14)
        )
        .padding(.horizontal, 16)
        .padding(.bottom, 20)
    }

    private func distanceText(for store: FashionStore) -> String? {
        guard let userCoord = locationManager.userLocation else { return nil }
        let userLocation = CLLocation(latitude: userCoord.latitude, longitude: userCoord.longitude)
        let storeLocation = CLLocation(latitude: store.coordinate.latitude, longitude: store.coordinate.longitude)
        let meters = userLocation.distance(from: storeLocation)
        let km = meters / 1000
        if km < 1 {
            return String(format: "%.0f m away", meters)
        } else {
            return String(format: "%.1f km away", km)
        }
    }

    private func openInMaps(store: FashionStore) {
        let placemark = MKPlacemark(coordinate: store.coordinate)
        let item = MKMapItem(placemark: placemark)
        item.name = store.name
        item.openInMaps()
    }
}

private struct FashionStore: Identifiable {
    let id = UUID()
    let name: String
    let coordinate: CLLocationCoordinate2D
}

private final class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    @Published var userLocation: CLLocationCoordinate2D? = nil

    private let manager = CLLocationManager()

    override init() {
        super.init()
        manager.delegate = self
    }

    func requestLocation() {
        if CLLocationManager.locationServicesEnabled() {
            manager.requestWhenInUseAuthorization()
            manager.requestLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        DispatchQueue.main.async {
            self.userLocation = location.coordinate
        }
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        // no-op; fall back to default region
    }
}

#Preview {
    NavigationStack {
        FashionStoresView()
    }
}
