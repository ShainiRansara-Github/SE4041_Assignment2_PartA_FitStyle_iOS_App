import SwiftUI
import Charts

struct MyWardrobeView: View {
    @Environment(\.colorScheme) private var colorScheme
    @EnvironmentObject var store: WardrobeStore
    @State private var query: String = ""
    @State private var appeared: Bool = false
    @State private var scrollOffset: CGFloat = 0
    @State private var contentHeight: CGFloat = 0
    @State private var viewportHeight: CGFloat = 0
    @State private var showScrollToTop: Bool = false
    @State private var showingInsights: Bool = false

    private var summary: [(ToneGroup, Int)] {
        let counts = Dictionary(grouping: store.items, by: { $0.toneGroup }).mapValues { $0.count }
        return ToneGroup.allCases.map { ($0, counts[$0] ?? 0) }
    }

    var body: some View {
        NavigationStack {
            ScrollViewReader { proxy in
                VStack(spacing: 0) {
                    // Fixed header: compact summary + insights button + search
                    VStack(spacing: 12) {
                        SummaryBars(summary: summary)
                            .cardStyle()
                        Button {
                            showingInsights = true
                        } label: {
                            HStack {
                                Text("View Wardrobe Insights")
                                    .font(.subheadline.weight(.semibold))
                                Spacer()
                                Image(systemName: "chart.bar.xaxis")
                            }
                        }
                        .buttonStyle(NeumorphicButtonStyle())

                        HStack(spacing: 10) {
                            Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                            TextField("Search by category or color", text: $query)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                        }
                        .padding(12)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.white)
                                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color(.systemGray5)))
                                .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 6)
                        )
                    }
                    .padding(16)
                    .background(colorScheme == .dark ? Color(.systemGray6) : Color.white)

                    Divider()

                    // Scrollable content: wardrobe items
                    ScrollView(.vertical) {
                        Color.clear.frame(height: 0).id("top")
                        VStack(alignment: .leading, spacing: 16) {
                            let groups = store.grouped(by: query)
                            if groups.isEmpty {
                                VStack(spacing: 8) {
                                    Image(systemName: "tray")
                                        .font(.system(size: 26))
                                        .foregroundStyle(.secondary)
                                    Text("No items match your search")
                                        .foregroundStyle(.secondary)
                                }
                                .padding(40)
                                .cardStyle()
                            } else {
                                ForEach(Array(groups.enumerated()), id: \.offset) { _, group in
                                    let (cat, items) = group
                                    VStack(alignment: .leading, spacing: 10) {
                                        HStack {
                                            Text(cat.title)
                                                .font(.headline)
                                            Spacer()
                                            Text("\(items.count)")
                                                .font(.subheadline)
                                                .foregroundStyle(.secondary)
                                        }
                                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 120), spacing: 12)], spacing: 12) {
                                            ForEach(items) { item in
                                                WardrobeItemCard(item: item)
                                            }
                                        }
                                    }
                                    .cardStyle()
                                }
                            }
                        }
                        .padding(16)
                        .background(
                            GeometryReader { geo in
                                Color.clear
                                    .preference(key: ContentHeightPreferenceKey.self, value: geo.size.height)
                            }
                        )
                        .background(
                            GeometryReader { geo in
                                Color.clear
                                    .preference(key: ScrollOffsetPreferenceKey.self, value: -geo.frame(in: .named("wardrobeScroll")).origin.y)
                            }
                        )
                    }
                    .coordinateSpace(name: "wardrobeScroll")
                    .scrollIndicators(.visible)
                    .onPreferenceChange(ScrollOffsetPreferenceKey.self) { value in
                        scrollOffset = value
                        let threshold = max(0, 0.6 * max(0, contentHeight - viewportHeight))
                        withAnimation(.easeInOut(duration: 0.2)) { showScrollToTop = scrollOffset > threshold }
                    }
                    .onPreferenceChange(ContentHeightPreferenceKey.self) { value in
                        contentHeight = value
                    }
                    .background(
                        GeometryReader { geo in
                            Color.clear
                                .onAppear { viewportHeight = geo.size.height }
                                .onChange(of: geo.size.height) { _, new in viewportHeight = new }
                        }
                    )
                    .overlay(alignment: .bottomTrailing) {
                        if showScrollToTop {
                            Button {
                                withAnimation(.spring(response: 0.45, dampingFraction: 0.85)) {
                                    proxy.scrollTo("top", anchor: .top)
                                }
                            } label: {
                                Image(systemName: "arrow.up.circle.fill")
                                    .font(.system(size: 28, weight: .semibold))
                                    .foregroundStyle(Color(hex: "F2A6B3"))
                                    .shadow(color: Color.black.opacity(0.15), radius: 8, x: 0, y: 6)
                            }
                            .padding(.trailing, 20)
                            .padding(.bottom, 28)
                            .transition(.scale.combined(with: .opacity))
                        }
                    }
                }
            }
            .background(colorScheme == .dark ? Color(.systemGray6) : Color.white)
            .navigationTitle("My Wardrobe")
            .onAppear { withAnimation { appeared = true } }
            .onReceive(NotificationCenter.default.publisher(for: .fitStyleOpenWardrobeInsights)) { _ in
                withAnimation { showingInsights = true }
            }
        }
        .sheet(isPresented: $showingInsights) {
            WardrobeInsightsView()
                .environmentObject(store)
        }
        .tint(Color.fitStyleAccent(for: colorScheme))
    }
}

extension Notification.Name {
    static let fitStyleOpenWardrobeInsights = Notification.Name("fitStyleOpenWardrobeInsights")
}

struct WardrobeStatisticsView: View {
    let summary: [(ToneGroup, Int)]
    let items: [WardrobeItem]

    private struct CategoryStat: Identifiable {
        let id = UUID()
        let label: String
        let icon: String
        let count: Int
        let color: Color
    }

    private var toneData: [(label: String, count: Int, color: Color)] {
        summary.map { pair in
            let (group, count) = pair
            switch group {
            case .neutral:
                return (group.rawValue, count, Color(.systemGray4))
            case .dark:
                return (group.rawValue, count, Color.black.opacity(0.75))
            case .bright:
                return (group.rawValue, count, Color(hex: "F2A6B3"))
            }
        }
    }

    private var categoryData: [CategoryStat] {
        let all = items
        func count(_ category: Category) -> Int { all.filter { $0.category == category }.count }
        return [
            CategoryStat(label: "Tops",        icon: "tshirt.fill",   count: count(.top),       color: Color(hex: "F2A6B3")),
            CategoryStat(label: "Bottoms",     icon: "hanger",        count: count(.bottom),    color: Color(hex: "A1C8F0")),
            CategoryStat(label: "Shoes",       icon: "shoe.fill",     count: count(.shoes),     color: Color(hex: "8B4513")),
            CategoryStat(label: "Accessories", icon: "sparkles",      count: count(.accessory), color: Color(hex: "F2C94C"))
        ].filter { $0.count > 0 }
    }

    private var totalCategoryCount: Int { categoryData.map { $0.count }.reduce(0, +) }

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Wardrobe Statistics")
                .font(.headline)

            // Tone distribution bar chart
            VStack(alignment: .leading, spacing: 8) {
                Text("Tones")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Chart(toneData, id: \.label) { item in
                    BarMark(
                        x: .value("Count", item.count),
                        y: .value("Tone", item.label)
                    )
                    .foregroundStyle(item.color)
                    .cornerRadius(8)
                }
                .chartXAxis {
                    AxisMarks(position: .bottom)
                }
                .chartYAxis {
                    AxisMarks(position: .leading)
                }
            }

            // Category distribution donut chart
            if totalCategoryCount > 0 {
                VStack(alignment: .leading, spacing: 10) {
                    Text("Categories")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    HStack(alignment: .center, spacing: 16) {
                        Chart(categoryData) { stat in
                            SectorMark(
                                angle: .value("Count", stat.count),
                                innerRadius: .ratio(0.55),
                                outerRadius: .ratio(0.95)
                            )
                            .foregroundStyle(stat.color)
                        }

                        VStack(alignment: .leading, spacing: 8) {
                            ForEach(categoryData) { stat in
                                HStack(spacing: 8) {
                                    Circle()
                                        .fill(stat.color)
                                        .frame(width: 10, height: 10)
                                    Image(systemName: stat.icon)
                                        .font(.system(size: 13))
                                        .foregroundStyle(.secondary)
                                    Text("\(stat.label) \(stat.count)")
                                        .font(.footnote)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private struct ScrollOffsetPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

private struct ContentHeightPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

struct WardrobeItemCard: View {
    let item: WardrobeItem

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack {
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color.white)
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color(.systemGray5)))
                    .shadow(color: Color.black.opacity(0.06), radius: 10, x: 0, y: 6)

                if let ui = item.image {
                    Image(uiImage: ui)
                        .resizable()
                        .scaledToFill()
                        .frame(height: 100)
                        .clipped()
                        .clipShape(RoundedRectangle(cornerRadius: 20))
                        .padding(6)
                } else {
                    VStack(spacing: 6) {
                        Image(systemName: "photo")
                            .font(.system(size: 22))
                            .foregroundStyle(.secondary)
                        Text("No photo")
                            .foregroundStyle(.secondary)
                            .font(.caption)
                    }
                    .padding(16)
                }
            }
            .frame(height: 110)

            HStack(spacing: 8) {
                RoundedRectangle(cornerRadius: 6)
                    .fill(item.color ?? Color(.systemGray5))
                    .frame(width: 18, height: 12)
                    .overlay(RoundedRectangle(cornerRadius: 6).stroke(Color(.systemGray5)))
                Text(item.category.title)
                    .font(.subheadline)
                Spacer()
                Text(item.dateAdded, style: .date)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }
}

struct SummaryBars: View {
    let summary: [(ToneGroup, Int)]

    private var total: Int { summary.map { $0.1 }.reduce(0, +) }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Wardrobe Summary")
                .font(.headline)
            if total == 0 {
                Text("No items yet.")
                    .foregroundStyle(.secondary)
                    .font(.subheadline)
            } else {
                let neutralCount = summary.first(where: { $0.0 == .neutral })?.1 ?? 0
                let darkCount = summary.first(where: { $0.0 == .dark })?.1 ?? 0
                let brightCount = summary.first(where: { $0.0 == .bright })?.1 ?? 0

                HStack(spacing: 12) {
                    HStack(spacing: 6) {
                        Circle()
                            .fill(color(for: .neutral))
                            .frame(width: 8, height: 8)
                        Text("Neutrals: \(neutralCount)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    HStack(spacing: 6) {
                        Circle()
                            .fill(color(for: .bright))
                            .frame(width: 8, height: 8)
                        Text("Brights: \(brightCount)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    HStack(spacing: 6) {
                        Circle()
                            .fill(color(for: .dark))
                            .frame(width: 8, height: 8)
                        Text("Darks: \(darkCount)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
    }

    private func color(for group: ToneGroup) -> Color {
        switch group {
        case .neutral: return Color(.systemGray4)
        case .dark: return .black.opacity(0.8)
        case .bright: return Color(hex: "F2A6B3")
        }
    }
}

struct WardrobeInsightsView: View {
    @Environment(\.colorScheme) private var colorScheme
    @EnvironmentObject var store: WardrobeStore
    @Environment(\.dismiss) private var dismiss

    private var summary: [(ToneGroup, Int)] {
        let counts = Dictionary(grouping: store.items, by: { $0.toneGroup }).mapValues { $0.count }
        return ToneGroup.allCases.map { ($0, counts[$0] ?? 0) }
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    WardrobeStatisticsView(summary: summary, items: store.items)
                        .cardStyle()
                }
                .padding(16)
            }
            .background(colorScheme == .dark ? Color(.systemGray6) : Color(.systemBackground))
            .navigationTitle("Wardrobe Insights")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                    }
                }
            }
        }
        .tint(Color.fitStyleAccent(for: colorScheme))
    }
}

#Preview {
    MyWardrobeView().environmentObject(WardrobeStore())
}
