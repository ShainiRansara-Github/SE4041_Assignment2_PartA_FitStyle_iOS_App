import SwiftUI

struct OnboardingView: View {
    @Binding var didShowOnboarding: Bool
    @Environment(\.colorScheme) private var colorScheme
    @State private var currentPage: Int = 0

    var body: some View {
        ZStack {
            (colorScheme == .dark ? Color(.systemGray6) : Color.white)
                .ignoresSafeArea()

            VStack(spacing: 0) {
                HStack {
                    Spacer()
                    Button("Skip") {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            didShowOnboarding = true
                        }
                    }
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)

                TabView(selection: $currentPage) {
                    onboardingPage(
                        title: "Organize Your Wardrobe",
                        message: "Capture or upload your clothes and keep everything in one place.",
                        systemImage: "hanger"
                    )
                    .tag(0)

                    onboardingPage(
                        title: "Smart Color Suggestions",
                        message: "Let AI-based color harmony suggest matching outfits.",
                        systemImage: "paintpalette.fill"
                    )
                    .tag(1)

                    onboardingPage(
                        title: "Save Your Favorite Looks",
                        message: "Plan outfits, save styles, and get ready faster.",
                        systemImage: "sparkles"
                    )
                    .tag(2)
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))

                VStack(spacing: 16) {
                    HStack(spacing: 8) {
                        ForEach(0..<3) { index in
                            Circle()
                                .fill(index == currentPage ? Color(hex: "F2A6B3") : Color(.systemGray4))
                                .frame(width: index == currentPage ? 10 : 6, height: index == currentPage ? 10 : 6)
                                .animation(.easeInOut(duration: 0.2), value: currentPage)
                        }
                    }

                    Button {
                        if currentPage < 2 {
                            withAnimation(.easeInOut(duration: 0.25)) {
                                currentPage += 1
                            }
                        } else {
                            withAnimation(.easeInOut(duration: 0.3)) {
                                didShowOnboarding = true
                            }
                        }
                    } label: {
                        Text(currentPage == 2 ? "Get Started" : "Next")
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                    }
                    .buttonStyle(PrimaryFillButtonStyle())
                    .padding(.horizontal, 20)
                    .padding(.bottom, 24)
                }
            }
        }
        .transition(.opacity.combined(with: .move(edge: .bottom)))
    }

    private func onboardingPage(title: String, message: String, systemImage: String) -> some View {
        VStack(spacing: 24) {
            Spacer(minLength: 24)

            VStack(spacing: 8) {
                Text("FitStyle")
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                    .foregroundStyle(Color(hex: "F2A6B3"))
                Text("Smart Outfit Recommender")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            .padding(.top, 8)

            Spacer(minLength: 16)

            Image(systemName: systemImage)
                .font(.system(size: 60, weight: .semibold))
                .foregroundStyle(Color.fitStyleAccent(for: colorScheme))
                .padding(24)
                .background(
                    Circle()
                        .fill((colorScheme == .dark ? Color(.systemGray5) : Color(hex: "FDE2E7")).opacity(0.8))
                )

            VStack(spacing: 8) {
                Text(title)
                    .font(.title2.weight(.semibold))
                    .multilineTextAlignment(.center)
                Text(message)
                    .font(.body)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 28)
            }

            Spacer()
        }
    }
}

#Preview {
    OnboardingView(didShowOnboarding: .constant(false))
}
