import SwiftUI

@main
struct Ass_2_part_1App: App {
    @StateObject private var store = WardrobeStore()
    @StateObject private var savedStore = SavedLooksStore()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .environmentObject(savedStore)
        }
    }
}
