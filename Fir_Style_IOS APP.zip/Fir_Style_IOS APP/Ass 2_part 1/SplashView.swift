import SwiftUI

struct SplashView: View {
    @State private var showSplash = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(hex: "FDE2E7"),   // soft light pink
                    Color(hex: "F2A6B3")    // FitStyle accent pink used elsewhere
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            VStack(spacing: 8) {
                Text("FitStyle")
                    .font(.system(size: 42, weight: .bold))
                    .foregroundColor(.white)
                    .opacity(showSplash ? 1 : 0)
                    .scaleEffect(showSplash ? 1 : 0.9)

                Text("Smart Outfit Recommender")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.white.opacity(0.9))
                    .opacity(showSplash ? 1 : 0)
            }
            .animation(.easeOut(duration: 0.7), value: showSplash)
        }
        .onAppear { showSplash = true }
        .transition(.move(edge: .top).combined(with: .opacity))
    }
}

#Preview {
    SplashView()
}
