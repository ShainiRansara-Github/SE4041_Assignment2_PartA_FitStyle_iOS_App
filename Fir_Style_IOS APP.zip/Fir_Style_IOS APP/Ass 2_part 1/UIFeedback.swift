import SwiftUI
import UIKit

enum ToastStyle {
    case success
    case info
    case delete

    var iconName: String {
        switch self {
        case .success: return "checkmark.circle.fill"
        case .info: return "info.circle.fill"
        case .delete: return "trash.circle.fill"
        }
    }

    var tintColor: Color {
        switch self {
        case .success: return Color.green
        case .info: return Color.blue
        case .delete: return Color.red
        }
    }
}

struct ToastMessage: Identifiable, Equatable {
    let id = UUID()
    let text: String
    let style: ToastStyle
}

struct ToastView: View {
    let message: ToastMessage

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: message.style.iconName)
                .foregroundStyle(.white)
            Text(message.text)
                .font(.subheadline)
                .foregroundStyle(.white)
        }
        .padding(.vertical, 10)
        .padding(.horizontal, 14)
        .background(
            Capsule()
                .fill(message.style.tintColor)
                .shadow(color: Color.black.opacity(0.18), radius: 14, x: 0, y: 10)
        )
        .padding(.horizontal, 20)
        .padding(.bottom, 20)
    }
}

struct ToastPresenter: ViewModifier {
    @Binding var toast: ToastMessage?

    func body(content: Content) -> some View {
        ZStack {
            content
            if let toast = toast {
                VStack {
                    Spacer()
                    ToastView(message: toast)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                }
            }
        }
        .animation(.easeInOut(duration: 0.25), value: toast)
    }
}

extension View {
    func toast(message: Binding<ToastMessage?>) -> some View {
        modifier(ToastPresenter(toast: message))
    }
}

enum Haptics {
    static func lightImpact() {
        let generator = UIImpactFeedbackGenerator(style: .light)
        generator.prepare()
        generator.impactOccurred()
    }
}

extension Color {
    static func fitStyleAccent(for colorScheme: ColorScheme) -> Color {
        let theme = UserDefaults.standard.string(forKey: "fitstyleAccentTheme") ?? "Soft Pink"

        switch theme {
        case "Lilac":
            return colorScheme == .dark
                ? Color(hex: "B79CFF")
                : Color(hex: "C7B5FF")
        case "Neutral":
            return colorScheme == .dark
                ? Color(.systemGray3)
                : Color(.systemGray)
        default: // "Soft Pink" (fallback)
            return colorScheme == .dark
                ? Color(hex: "CE7A8A")
                : Color(hex: "F2A6B3")
        }
    }
}
