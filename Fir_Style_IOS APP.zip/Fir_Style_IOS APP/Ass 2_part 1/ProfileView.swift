import SwiftUI

struct ProfileView: View {
    @Environment(\.colorScheme) private var colorScheme
    @EnvironmentObject var store: WardrobeStore
    @EnvironmentObject var savedStore: SavedLooksStore
    @Binding var selectedTab: Tab

    @AppStorage("fitstyle_username") private var userName: String = "FitStyle User"
    @AppStorage("fitstyleAccentTheme") private var accentTheme: String = "Soft Pink"
    @AppStorage("fitstyleReduceAnimations") private var reduceAnimations: Bool = false

    @State private var isEditingName: Bool = false
    @State private var tempName: String = ""
    @State private var showDocumentation: Bool = false

    private var totalItems: Int { store.items.count }
    private var topsCount: Int { store.items.filter { $0.category == .top }.count }
    private var bottomsCount: Int { store.items.filter { $0.category == .bottom }.count }
    private var shoesCount: Int { store.items.filter { $0.category == .shoes }.count }
    private var accessoriesCount: Int { store.items.filter { $0.category == .accessory }.count }
    private var savedLooksCount: Int { savedStore.looks.count }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    headerSection

                    statsSection

                    shortcutsSection

                    preferencesSection

                    aboutSection
                }
                .padding()
            }
            .background(colorScheme == .dark ? Color(.systemGray6) : Color.white)
            .navigationTitle("Profile")
            .onAppear {
                if tempName.isEmpty { tempName = userName }
            }
            .sheet(isPresented: $isEditingName) {
                NavigationStack {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Edit Name")
                            .font(.headline)
                        TextField("Enter your name", text: $tempName)
                            .textInputAutocapitalization(.words)
                            .padding(10)
                            .background(RoundedRectangle(cornerRadius: 12).fill(Color(.secondarySystemBackground)))
                        Spacer()
                    }
                    .padding()
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Cancel") {
                                tempName = userName
                                isEditingName = false
                            }
                        }
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Save") {
                                let trimmed = tempName.trimmingCharacters(in: .whitespacesAndNewlines)
                                userName = trimmed.isEmpty ? "FitStyle User" : trimmed
                                isEditingName = false
                            }
                        }
                    }
                }
            }
            .sheet(isPresented: $showDocumentation) {
                NavigationStack {
                    VStack(alignment: .leading, spacing: 16) {
                        Text("FitStyle Documentation")
                            .font(.title3.weight(.semibold))
                        Text("This is FitStyle's documentation screen.")
                            .font(.body)
                        Spacer()
                    }
                    .padding()
                    .navigationTitle("Documentation")
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Done") { showDocumentation = false }
                        }
                    }
                }
            }
        }
    }

    private var headerSection: some View {
        VStack(spacing: 14) {
            Circle()
                .fill(
                    LinearGradient(
                        colors: [Color.fitStyleAccent(for: colorScheme), Color.fitStyleAccent(for: colorScheme).opacity(0.6)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: 96, height: 96)
                .overlay(
                    Image(systemName: "person.fill")
                        .font(.system(size: 40, weight: .semibold))
                        .foregroundStyle(.white)
                )

            VStack(spacing: 4) {
                Text("Hi, \(userName.isEmpty ? "FitStyle User" : userName)")
                    .font(.title3.weight(.semibold))
                Text("Your smart outfit assistant")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Button {
                tempName = userName
                isEditingName = true
            } label: {
                HStack {
                    Image(systemName: "pencil")
                    Text("Edit Name")
                }
            }
            .buttonStyle(NeumorphicButtonStyle())
        }
        .cardStyle()
    }

    private var statsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Wardrobe Overview")
                .font(.headline)
            Text("Quick snapshot of your wardrobe and saved looks.")
                .font(.footnote)
                .foregroundStyle(.secondary)

            HStack(spacing: 16) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Total items")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Text("\(totalItems)")
                        .font(.title3.weight(.semibold))
                }

                Spacer()

                VStack(alignment: .leading, spacing: 4) {
                    Text("Saved looks")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                    Text("\(savedLooksCount)")
                        .font(.title3.weight(.semibold))
                }
            }

            Divider().padding(.vertical, 4)

            HStack(spacing: 12) {
                statPill(label: "Tops", value: topsCount, systemImage: "tshirt.fill")
                statPill(label: "Bottoms", value: bottomsCount, systemImage: "hanger")
            }

            HStack(spacing: 12) {
                statPill(label: "Shoes", value: shoesCount, systemImage: "shoe.fill")
                statPill(label: "Accessories", value: accessoriesCount, systemImage: "sparkles")
            }
        }
        .cardStyle()
    }

    private func statPill(label: String, value: Int, systemImage: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: systemImage)
                .font(.system(size: 14))
                .foregroundStyle(Color.fitStyleAccent(for: colorScheme))
            Text("\(label): \(value)")
                .font(.footnote)
        }
        .padding(.vertical, 6)
        .padding(.horizontal, 10)
        .background(
            Capsule()
                .fill(Color(.secondarySystemBackground).opacity(colorScheme == .dark ? 0.4 : 0.9))
        )
    }

    private var shortcutsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Shortcuts")
                .font(.headline)
            Text("Jump quickly to your most-used screens.")
                .font(.footnote)
                .foregroundStyle(.secondary)

            VStack(spacing: 10) {
                Button {
                    selectedTab = .wardrobe
                } label: {
                    HStack {
                        Image(systemName: "closet")
                        Text("Open My Wardrobe")
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
                .buttonStyle(NeumorphicButtonStyle())

                Button {
                    selectedTab = .saved
                } label: {
                    HStack {
                        Image(systemName: "heart.text.square")
                        Text("Open Saved Looks")
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
                .buttonStyle(NeumorphicButtonStyle())

                Button {
                    selectedTab = .wardrobe
                    NotificationCenter.default.post(name: .fitStyleOpenWardrobeInsights, object: nil)
                } label: {
                    HStack {
                        Image(systemName: "chart.bar.xaxis")
                        Text("View Wardrobe Insights")
                        Spacer()
                        Image(systemName: "chevron.right")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                }
                .buttonStyle(NeumorphicButtonStyle())
            }
        }
        .cardStyle()
    }

    private var preferencesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("App Preferences")
                .font(.headline)
            Text("Customize how FitStyle feels.")
                .font(.footnote)
                .foregroundStyle(.secondary)

            VStack(alignment: .leading, spacing: 10) {
                Text("Accent theme")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Picker("Accent theme", selection: $accentTheme) {
                    Text("Pink").tag("Soft Pink")
                    Text("Purple").tag("Lilac")
                    Text("Blue").tag("Neutral")
                }
                .pickerStyle(.segmented)
            }

            Toggle(isOn: $reduceAnimations) {
                Text("Reduce animations")
                    .font(.subheadline)
            }
            .tint(Color.fitStyleAccent(for: colorScheme))
        }
        .cardStyle()
    }

    private var aboutSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("About FitStyle")
                .font(.headline)
            Text("FitStyle v1.0")
                .font(.footnote.weight(.semibold))
            Text("SE4041 – Mobile App Design & Development")
                .font(.footnote)
                .foregroundStyle(.secondary)
            Text("Student: Shehan Dulmina")
                .font(.footnote)
            Text("ID: IT22xxxx")
                .font(.footnote)

            Button {
                showDocumentation = true
            } label: {
                HStack(spacing: 4) {
                    Text("View Documentation")
                    Image(systemName: "arrow.up.right")
                        .font(.footnote)
                }
            }
            .buttonStyle(NeumorphicButtonStyle())
        }
        .cardStyle()
    }
}

#Preview {
    ProfileView(selectedTab: .constant(.profile))
        .environmentObject(WardrobeStore())
        .environmentObject(SavedLooksStore())
}
