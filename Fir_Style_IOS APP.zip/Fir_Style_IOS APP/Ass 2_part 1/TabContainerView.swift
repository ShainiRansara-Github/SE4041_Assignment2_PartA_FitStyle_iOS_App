import SwiftUI

enum Tab: String, CaseIterable {
    case home
    case wardrobe
    case suggestions
    case saved
    case stores
    case profile

    var title: String {
        switch self {
        case .home: return "Home"
        case .wardrobe: return "Wardrobe"
        case .suggestions: return "Suggestions"
        case .saved: return "Saved"
        case .stores: return "Stores"
        case .profile: return "Profile"
        }
    }

    var systemImage: String {
        switch self {
        case .home: return "house.fill"
        case .wardrobe: return "hanger"
        case .suggestions: return "sparkles"
        case .saved: return "heart.text.square"
        case .stores: return "map"
        case .profile: return "person.crop.circle"
        }
    }
}

struct TabContainerView: View {
    @Environment(\.colorScheme) private var colorScheme
    @Namespace private var tabNamespace
    @State private var selectedTab: Tab = .home

    var body: some View {
        ZStack(alignment: .bottom) {
            Group {
                switch selectedTab {
                case .home:
                    HomeView(selectedTab: $selectedTab)
                case .wardrobe:
                    MyWardrobeView()
                case .suggestions:
                    OutfitSuggestionsView()
                case .saved:
                    SavedLooksView()
                case .stores:
                    FashionStoresView()
                case .profile:
                    ProfileView(selectedTab: $selectedTab)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .transition(.opacity)
            .animation(.easeInOut(duration: 0.22), value: selectedTab)

            customTabBar
        }
        .ignoresSafeArea(edges: .bottom)
    }

    private var customTabBar: some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                ForEach(Tab.allCases, id: \.self) { tab in
                    tabButton(for: tab)
                }
            }
            .padding(.horizontal, 10)
            .frame(height: 58)
            .background(.ultraThinMaterial)
            .shadow(color: Color.black.opacity(0.12), radius: 12, x: 0, y: -2)
        }
        .ignoresSafeArea(edges: .bottom)
    }

    private func tabButton(for tab: Tab) -> some View {
        let isSelected = tab == selectedTab

        return Button {
            withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
                selectedTab = tab
            }
        } label: {
            VStack(alignment: .center, spacing: 2) {
                Image(systemName: tab.systemImage)
                    .font(.system(size: isSelected ? 26 : 22, weight: isSelected ? .semibold : .regular))
                    .scaleEffect(isSelected ? 1.08 : 1.0)
                    .foregroundStyle(isSelected ? Color.fitStyleAccent(for: colorScheme) : Color.secondary)
                    .padding(.horizontal, 4)

                Text(tab.title)
                    .font(.system(size: 12, weight: .medium))
                    .lineLimit(1)
                    .minimumScaleFactor(0.9)
                    .opacity(isSelected ? 1.0 : 0.0)
                    .foregroundStyle(isSelected ? Color.primary : Color.secondary)
                    .animation(.easeInOut(duration: 0.2), value: isSelected)
            }
            .frame(maxWidth: .infinity)
            .padding(.top, 6)
            .padding(.bottom, 8)
        }
        .contentShape(Rectangle())
        .buttonStyle(.plain)
    }
}

#Preview {
    TabContainerView()
        .environmentObject(WardrobeStore())
        .environmentObject(SavedLooksStore())
}
